
<!-- Page content ends here -->

</main> <!-- End of main content wrapper from header.php -->

<footer class="bg-light text-center text-lg-start mt-auto py-3">
    <div class="container">
        <p class="text-center text-muted mb-0">&copy; <?php echo date("Y"); ?> Academic Progress Tracker. All Rights Reserved.</p>
        <!-- Add more footer content if needed -->
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<!-- Add other custom JS files here if needed -->
<!-- e.g., <script src="<?php echo BASE_URL; ?>js/custom.js"></script> -->

</body>
</html>
